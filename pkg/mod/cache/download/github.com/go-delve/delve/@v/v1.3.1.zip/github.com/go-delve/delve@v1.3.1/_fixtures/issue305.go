package main

func main() {
	for i := 0; i < 10; i++ {
		println(i)
	}
}
